create function get_employees_by_job(p_job character varying) returns SETOF employee
    language plpgsql
as
$$DECLARE 
	myemployee employee;
BEGIN
	FOR myemployee IN
	SELECT * FROM employee
	WHERE LOWER(job) LIKE LOWER(p_job)
	LOOP
		RETURN NEXT myemployee;
	END LOOP;
END
$$;

alter function get_employees_by_job(varchar) owner to postgres;

