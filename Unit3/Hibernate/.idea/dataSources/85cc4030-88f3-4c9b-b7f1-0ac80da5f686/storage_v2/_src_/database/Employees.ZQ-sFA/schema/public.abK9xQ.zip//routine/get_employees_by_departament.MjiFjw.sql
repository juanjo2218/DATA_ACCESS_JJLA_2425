create function get_employees_by_departament(p_departament character varying) returns SETOF employee
    language plpgsql
as
$$DECLARE
	myemployee employee;
BEGIN
	FOR myemployee IN
		SELECT * 
		FROM employee e,
		     dept d
		WHERE e.deptno IN (SELECT d.deptno
						 FROM dept
						 WHERE LOWER(d.dname) LIKE LOWER(p_departament))
		AND e.deptno = d.deptno 
	LOOP 
	RETURN NEXT myemployee;
	END LOOP;
END;$$;

alter function get_employees_by_departament(varchar) owner to postgres;

