create function get_employees_by_name(p_name character varying) returns SETOF employee
    language plpgsql
as
$$DECLARE	
	myemployee employee;
BEGIN
	FOR myemployee IN
	SELECT * FROM employee
	WHERE LOWER(ename) LIKE LOWER(p_name)
	LOOP
		RETURN NEXT myemployee; 
	END LOOP;
END$$;

alter function get_employees_by_name(varchar) owner to postgres;

